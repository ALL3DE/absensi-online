gdjs.LEVEL3Code = {};
gdjs.LEVEL3Code.localVariables = [];
gdjs.LEVEL3Code.GDDownKeyObjects1_1final = [];

gdjs.LEVEL3Code.GDDownKeyObjects2_1final = [];

gdjs.LEVEL3Code.GDGoalObjects2_1final = [];

gdjs.LEVEL3Code.GDLeftKeyObjects1_1final = [];

gdjs.LEVEL3Code.GDLeftKeyObjects2_1final = [];

gdjs.LEVEL3Code.GDMarkerObjects2_1final = [];

gdjs.LEVEL3Code.GDRightKeyObjects1_1final = [];

gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2_1final = [];

gdjs.LEVEL3Code.GDUpKeyObjects1_1final = [];

gdjs.LEVEL3Code.GDUpKeyObjects2_1final = [];

gdjs.LEVEL3Code.GDPlayerObjects1= [];
gdjs.LEVEL3Code.GDPlayerObjects2= [];
gdjs.LEVEL3Code.GDPlayerObjects3= [];
gdjs.LEVEL3Code.GDBoxObjects1= [];
gdjs.LEVEL3Code.GDBoxObjects2= [];
gdjs.LEVEL3Code.GDBoxObjects3= [];
gdjs.LEVEL3Code.GDMarkerObjects1= [];
gdjs.LEVEL3Code.GDMarkerObjects2= [];
gdjs.LEVEL3Code.GDMarkerObjects3= [];
gdjs.LEVEL3Code.GDFloorObjects1= [];
gdjs.LEVEL3Code.GDFloorObjects2= [];
gdjs.LEVEL3Code.GDFloorObjects3= [];
gdjs.LEVEL3Code.GDGoalObjects1= [];
gdjs.LEVEL3Code.GDGoalObjects2= [];
gdjs.LEVEL3Code.GDGoalObjects3= [];
gdjs.LEVEL3Code.GDResetGameButtonObjects1= [];
gdjs.LEVEL3Code.GDResetGameButtonObjects2= [];
gdjs.LEVEL3Code.GDResetGameButtonObjects3= [];
gdjs.LEVEL3Code.GDYouWinObjects1= [];
gdjs.LEVEL3Code.GDYouWinObjects2= [];
gdjs.LEVEL3Code.GDYouWinObjects3= [];
gdjs.LEVEL3Code.GDUpKeyObjects1= [];
gdjs.LEVEL3Code.GDUpKeyObjects2= [];
gdjs.LEVEL3Code.GDUpKeyObjects3= [];
gdjs.LEVEL3Code.GDRightKeyObjects1= [];
gdjs.LEVEL3Code.GDRightKeyObjects2= [];
gdjs.LEVEL3Code.GDRightKeyObjects3= [];
gdjs.LEVEL3Code.GDLeftKeyObjects1= [];
gdjs.LEVEL3Code.GDLeftKeyObjects2= [];
gdjs.LEVEL3Code.GDLeftKeyObjects3= [];
gdjs.LEVEL3Code.GDDownKeyObjects1= [];
gdjs.LEVEL3Code.GDDownKeyObjects2= [];
gdjs.LEVEL3Code.GDDownKeyObjects3= [];
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects1= [];
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2= [];
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3= [];
gdjs.LEVEL3Code.GDblueboxObjects1= [];
gdjs.LEVEL3Code.GDblueboxObjects2= [];
gdjs.LEVEL3Code.GDblueboxObjects3= [];
gdjs.LEVEL3Code.GDBlueTargetObjects1= [];
gdjs.LEVEL3Code.GDBlueTargetObjects2= [];
gdjs.LEVEL3Code.GDBlueTargetObjects3= [];
gdjs.LEVEL3Code.GDredboxObjects1= [];
gdjs.LEVEL3Code.GDredboxObjects2= [];
gdjs.LEVEL3Code.GDredboxObjects3= [];
gdjs.LEVEL3Code.GDredtargetObjects1= [];
gdjs.LEVEL3Code.GDredtargetObjects2= [];
gdjs.LEVEL3Code.GDredtargetObjects3= [];
gdjs.LEVEL3Code.GDgreenboxObjects1= [];
gdjs.LEVEL3Code.GDgreenboxObjects2= [];
gdjs.LEVEL3Code.GDgreenboxObjects3= [];
gdjs.LEVEL3Code.GDgreentargetObjects1= [];
gdjs.LEVEL3Code.GDgreentargetObjects2= [];
gdjs.LEVEL3Code.GDgreentargetObjects3= [];
gdjs.LEVEL3Code.GDgreyboxObjects1= [];
gdjs.LEVEL3Code.GDgreyboxObjects2= [];
gdjs.LEVEL3Code.GDgreyboxObjects3= [];


gdjs.LEVEL3Code.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20695516);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DownKey"), gdjs.LEVEL3Code.GDDownKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("LeftKey"), gdjs.LEVEL3Code.GDLeftKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("RightKey"), gdjs.LEVEL3Code.GDRightKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("UpKey"), gdjs.LEVEL3Code.GDUpKeyObjects1);
{for(var i = 0, len = gdjs.LEVEL3Code.GDUpKeyObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDUpKeyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LEVEL3Code.GDRightKeyObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDRightKeyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LEVEL3Code.GDLeftKeyObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDLeftKeyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LEVEL3Code.GDDownKeyObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDDownKeyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LEVEL3Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LEVEL3Code.GDLeftKeyObjects1, gdjs.LEVEL3Code.GDLeftKeyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDLeftKeyObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDLeftKeyObjects1, gdjs.LEVEL3Code.GDLeftKeyObjects3);

for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDLeftKeyObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDLeftKeyObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDLeftKeyObjects3[k] = gdjs.LEVEL3Code.GDLeftKeyObjects3[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDLeftKeyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDLeftKeyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDLeftKeyObjects2_1final.indexOf(gdjs.LEVEL3Code.GDLeftKeyObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDLeftKeyObjects2_1final.push(gdjs.LEVEL3Code.GDLeftKeyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDLeftKeyObjects2_1final, gdjs.LEVEL3Code.GDLeftKeyObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(-(64));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}}

}


{

gdjs.copyArray(gdjs.LEVEL3Code.GDDownKeyObjects1, gdjs.LEVEL3Code.GDDownKeyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDDownKeyObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDDownKeyObjects1, gdjs.LEVEL3Code.GDDownKeyObjects3);

for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDDownKeyObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDDownKeyObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDDownKeyObjects3[k] = gdjs.LEVEL3Code.GDDownKeyObjects3[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDDownKeyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDDownKeyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDDownKeyObjects2_1final.indexOf(gdjs.LEVEL3Code.GDDownKeyObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDDownKeyObjects2_1final.push(gdjs.LEVEL3Code.GDDownKeyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDDownKeyObjects2_1final, gdjs.LEVEL3Code.GDDownKeyObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}}

}


{

gdjs.copyArray(gdjs.LEVEL3Code.GDUpKeyObjects1, gdjs.LEVEL3Code.GDUpKeyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDUpKeyObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDUpKeyObjects1, gdjs.LEVEL3Code.GDUpKeyObjects3);

for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDUpKeyObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDUpKeyObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDUpKeyObjects3[k] = gdjs.LEVEL3Code.GDUpKeyObjects3[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDUpKeyObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDUpKeyObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDUpKeyObjects2_1final.indexOf(gdjs.LEVEL3Code.GDUpKeyObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDUpKeyObjects2_1final.push(gdjs.LEVEL3Code.GDUpKeyObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDUpKeyObjects2_1final, gdjs.LEVEL3Code.GDUpKeyObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(-(64));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}}

}


{

/* Reuse gdjs.LEVEL3Code.GDRightKeyObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDRightKeyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDRightKeyObjects1, gdjs.LEVEL3Code.GDRightKeyObjects2);

for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDRightKeyObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDRightKeyObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDRightKeyObjects2[k] = gdjs.LEVEL3Code.GDRightKeyObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDRightKeyObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDRightKeyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDRightKeyObjects1_1final.indexOf(gdjs.LEVEL3Code.GDRightKeyObjects2[j]) === -1 )
            gdjs.LEVEL3Code.GDRightKeyObjects1_1final.push(gdjs.LEVEL3Code.GDRightKeyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDRightKeyObjects1_1final, gdjs.LEVEL3Code.GDRightKeyObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}}

}


};gdjs.LEVEL3Code.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.LEVEL3Code.GDDownKeyObjects1.length = 0;

gdjs.LEVEL3Code.GDLeftKeyObjects1.length = 0;

gdjs.LEVEL3Code.GDRightKeyObjects1.length = 0;

gdjs.LEVEL3Code.GDUpKeyObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDDownKeyObjects1_1final.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects1_1final.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects1_1final.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("DownKey"), gdjs.LEVEL3Code.GDDownKeyObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftKey"), gdjs.LEVEL3Code.GDLeftKeyObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightKey"), gdjs.LEVEL3Code.GDRightKeyObjects2);
gdjs.copyArray(runtimeScene.getObjects("UpKey"), gdjs.LEVEL3Code.GDUpKeyObjects2);
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDUpKeyObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDUpKeyObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDUpKeyObjects2[k] = gdjs.LEVEL3Code.GDUpKeyObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDUpKeyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDRightKeyObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDRightKeyObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDRightKeyObjects2[k] = gdjs.LEVEL3Code.GDRightKeyObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDRightKeyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDLeftKeyObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDLeftKeyObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDLeftKeyObjects2[k] = gdjs.LEVEL3Code.GDLeftKeyObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDLeftKeyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDDownKeyObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDDownKeyObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.LEVEL3Code.GDDownKeyObjects2[k] = gdjs.LEVEL3Code.GDDownKeyObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDDownKeyObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDDownKeyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDDownKeyObjects1_1final.indexOf(gdjs.LEVEL3Code.GDDownKeyObjects2[j]) === -1 )
            gdjs.LEVEL3Code.GDDownKeyObjects1_1final.push(gdjs.LEVEL3Code.GDDownKeyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDLeftKeyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDLeftKeyObjects1_1final.indexOf(gdjs.LEVEL3Code.GDLeftKeyObjects2[j]) === -1 )
            gdjs.LEVEL3Code.GDLeftKeyObjects1_1final.push(gdjs.LEVEL3Code.GDLeftKeyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDRightKeyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDRightKeyObjects1_1final.indexOf(gdjs.LEVEL3Code.GDRightKeyObjects2[j]) === -1 )
            gdjs.LEVEL3Code.GDRightKeyObjects1_1final.push(gdjs.LEVEL3Code.GDRightKeyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDUpKeyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDUpKeyObjects1_1final.indexOf(gdjs.LEVEL3Code.GDUpKeyObjects2[j]) === -1 )
            gdjs.LEVEL3Code.GDUpKeyObjects1_1final.push(gdjs.LEVEL3Code.GDUpKeyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDDownKeyObjects1_1final, gdjs.LEVEL3Code.GDDownKeyObjects1);
gdjs.copyArray(gdjs.LEVEL3Code.GDLeftKeyObjects1_1final, gdjs.LEVEL3Code.GDLeftKeyObjects1);
gdjs.copyArray(gdjs.LEVEL3Code.GDRightKeyObjects1_1final, gdjs.LEVEL3Code.GDRightKeyObjects1);
gdjs.copyArray(gdjs.LEVEL3Code.GDUpKeyObjects1_1final, gdjs.LEVEL3Code.GDUpKeyObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20696948);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}
{ //Subevents
gdjs.LEVEL3Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects2Objects = Hashtable.newFrom({"Marker": gdjs.LEVEL3Code.GDMarkerObjects2});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects = Hashtable.newFrom({"Marker": gdjs.LEVEL3Code.GDMarkerObjects3});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects3ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Box": gdjs.LEVEL3Code.GDBoxObjects3, "Player": gdjs.LEVEL3Code.GDPlayerObjects3});
gdjs.LEVEL3Code.eventsList3 = function(runtimeScene) {

};gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects = Hashtable.newFrom({"Marker": gdjs.LEVEL3Code.GDMarkerObjects3});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDTilemap_95959595ObstaclesObjects3Objects = Hashtable.newFrom({"Tilemap_Obstacles": gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects = Hashtable.newFrom({"Marker": gdjs.LEVEL3Code.GDMarkerObjects3});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects3Objects = Hashtable.newFrom({"Goal": gdjs.LEVEL3Code.GDGoalObjects3});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Box": gdjs.LEVEL3Code.GDBoxObjects2, "Player": gdjs.LEVEL3Code.GDPlayerObjects2});
gdjs.LEVEL3Code.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.LEVEL3Code.GDBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL3Code.GDBoxObjects2 */
/* Reuse gdjs.LEVEL3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LEVEL3Code.GDBoxObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDBoxObjects2[i].returnVariable(gdjs.LEVEL3Code.GDBoxObjects2[i].getVariables().get("Direction")).setString("None");
}
for(var i = 0, len = gdjs.LEVEL3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDPlayerObjects2[i].returnVariable(gdjs.LEVEL3Code.GDPlayerObjects2[i].getVariables().get("Direction")).setString("None");
}
}}

}


};gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects2Objects = Hashtable.newFrom({"Marker": gdjs.LEVEL3Code.GDMarkerObjects2});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Box": gdjs.LEVEL3Code.GDBoxObjects2, "Player": gdjs.LEVEL3Code.GDPlayerObjects2});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Box": gdjs.LEVEL3Code.GDBoxObjects2, "Player": gdjs.LEVEL3Code.GDPlayerObjects2});
gdjs.LEVEL3Code.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.LEVEL3Code.GDBoxObjects2 */
/* Reuse gdjs.LEVEL3Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDBoxObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDBoxObjects2[i].getVariableString(gdjs.LEVEL3Code.GDBoxObjects2[i].getVariables().get("Direction")) == "Move" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL3Code.GDBoxObjects2[k] = gdjs.LEVEL3Code.GDBoxObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDBoxObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDPlayerObjects2[i].getVariableString(gdjs.LEVEL3Code.GDPlayerObjects2[i].getVariables().get("Direction")) == "Move" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL3Code.GDPlayerObjects2[k] = gdjs.LEVEL3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL3Code.GDBoxObjects2 */
/* Reuse gdjs.LEVEL3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.LEVEL3Code.GDBoxObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDBoxObjects2[i].setPosition((gdjs.LEVEL3Code.GDBoxObjects2[i].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)),(gdjs.LEVEL3Code.GDBoxObjects2[i].getPointY("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
for(var i = 0, len = gdjs.LEVEL3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDPlayerObjects2[i].setPosition((gdjs.LEVEL3Code.GDPlayerObjects2[i].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)),(gdjs.LEVEL3Code.GDPlayerObjects2[i].getPointY("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.LEVEL3Code.GDBoxObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDBoxObjects2[i].returnVariable(gdjs.LEVEL3Code.GDBoxObjects2[i].getVariables().get("Direction")).setString("None");
}
for(var i = 0, len = gdjs.LEVEL3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDPlayerObjects2[i].returnVariable(gdjs.LEVEL3Code.GDPlayerObjects2[i].getVariables().get("Direction")).setString("None");
}
}}

}


};gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects1Objects = Hashtable.newFrom({"Box": gdjs.LEVEL3Code.GDBoxObjects1});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects = Hashtable.newFrom({"Goal": gdjs.LEVEL3Code.GDGoalObjects1});
gdjs.LEVEL3Code.eventsList6 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) != 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) != 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL3Code.GDPlayerObjects2);
gdjs.LEVEL3Code.GDMarkerObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects2Objects, (( gdjs.LEVEL3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LEVEL3Code.GDPlayerObjects2[0].getPointX("")), (( gdjs.LEVEL3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LEVEL3Code.GDPlayerObjects2[0].getPointY("")), "");
}}

}


{


let stopDoWhile_0 = false;
do {
gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.LEVEL3Code.GDBoxObjects3);
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.LEVEL3Code.GDMarkerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL3Code.GDPlayerObjects3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects, gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects3ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.LEVEL3Code.GDBoxObjects3.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDBoxObjects3[i].returnVariable(gdjs.LEVEL3Code.GDBoxObjects3[i].getVariables().get("Direction")).setString("Move");
}
for(var i = 0, len = gdjs.LEVEL3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDPlayerObjects3[i].returnVariable(gdjs.LEVEL3Code.GDPlayerObjects3[i].getVariables().get("Direction")).setString("Move");
}
}{for(var i = 0, len = gdjs.LEVEL3Code.GDMarkerObjects3.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDMarkerObjects3[i].setPosition((( gdjs.LEVEL3Code.GDPlayerObjects3.length === 0 ) ? (( gdjs.LEVEL3Code.GDBoxObjects3.length === 0 ) ? 0 :gdjs.LEVEL3Code.GDBoxObjects3[0].getPointX("")) :gdjs.LEVEL3Code.GDPlayerObjects3[0].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)),(( gdjs.LEVEL3Code.GDPlayerObjects3.length === 0 ) ? (( gdjs.LEVEL3Code.GDBoxObjects3.length === 0 ) ? 0 :gdjs.LEVEL3Code.GDBoxObjects3[0].getPointY("")) :gdjs.LEVEL3Code.GDPlayerObjects3[0].getPointY("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}
{ //Subevents: 
gdjs.LEVEL3Code.eventsList3(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


{



}


{

gdjs.LEVEL3Code.GDGoalObjects2.length = 0;

gdjs.LEVEL3Code.GDMarkerObjects2.length = 0;

gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.LEVEL3Code.GDGoalObjects2_1final.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects2_1final.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.LEVEL3Code.GDMarkerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Obstacles"), gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects, gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDTilemap_95959595ObstaclesObjects3Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDMarkerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDMarkerObjects2_1final.indexOf(gdjs.LEVEL3Code.GDMarkerObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDMarkerObjects2_1final.push(gdjs.LEVEL3Code.GDMarkerObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2_1final.indexOf(gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2_1final.push(gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Goal"), gdjs.LEVEL3Code.GDGoalObjects3);
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.LEVEL3Code.GDMarkerObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects3Objects, gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDGoalObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDGoalObjects3[i].getBehavior("Animation").getAnimationName() == "Filled" ) {
        isConditionTrue_2 = true;
        gdjs.LEVEL3Code.GDGoalObjects3[k] = gdjs.LEVEL3Code.GDGoalObjects3[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDGoalObjects3.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDGoalObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDGoalObjects2_1final.indexOf(gdjs.LEVEL3Code.GDGoalObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDGoalObjects2_1final.push(gdjs.LEVEL3Code.GDGoalObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.LEVEL3Code.GDMarkerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.LEVEL3Code.GDMarkerObjects2_1final.indexOf(gdjs.LEVEL3Code.GDMarkerObjects3[j]) === -1 )
            gdjs.LEVEL3Code.GDMarkerObjects2_1final.push(gdjs.LEVEL3Code.GDMarkerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.LEVEL3Code.GDGoalObjects2_1final, gdjs.LEVEL3Code.GDGoalObjects2);
gdjs.copyArray(gdjs.LEVEL3Code.GDMarkerObjects2_1final, gdjs.LEVEL3Code.GDMarkerObjects2);
gdjs.copyArray(gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2_1final, gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL3Code.GDMarkerObjects2 */
{for(var i = 0, len = gdjs.LEVEL3Code.GDMarkerObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDMarkerObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LEVEL3Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.LEVEL3Code.GDBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.LEVEL3Code.GDMarkerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDMarkerObjects2Objects, gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects2ObjectsGDgdjs_9546LEVEL3Code_9546GDPlayerObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL3Code.GDMarkerObjects2 */
{for(var i = 0, len = gdjs.LEVEL3Code.GDMarkerObjects2.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDMarkerObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LEVEL3Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.LEVEL3Code.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Goal"), gdjs.LEVEL3Code.GDGoalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDBoxObjects1Objects, gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDGoalObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDGoalObjects1[i].getBehavior("Animation").getAnimationName() == "Empty" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL3Code.GDGoalObjects1[k] = gdjs.LEVEL3Code.GDGoalObjects1[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDGoalObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL3Code.GDBoxObjects1 */
/* Reuse gdjs.LEVEL3Code.GDGoalObjects1 */
{for(var i = 0, len = gdjs.LEVEL3Code.GDBoxObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LEVEL3Code.GDGoalObjects1.length ;i < len;++i) {
    gdjs.LEVEL3Code.GDGoalObjects1[i].getBehavior("Animation").setAnimationName("Filled");
}
}}

}


};gdjs.LEVEL3Code.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("ResetGameButton"), gdjs.LEVEL3Code.GDResetGameButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDResetGameButtonObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDResetGameButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL3Code.GDResetGameButtonObjects1[k] = gdjs.LEVEL3Code.GDResetGameButtonObjects1[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDResetGameButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


};gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects = Hashtable.newFrom({"Goal": gdjs.LEVEL3Code.GDGoalObjects1});
gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects = Hashtable.newFrom({"Goal": gdjs.LEVEL3Code.GDGoalObjects1});
gdjs.LEVEL3Code.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Goal"), gdjs.LEVEL3Code.GDGoalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "WinGame"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL3Code.GDGoalObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL3Code.GDGoalObjects1[i].getBehavior("Animation").getAnimationName() == "Filled" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL3Code.GDGoalObjects1[k] = gdjs.LEVEL3Code.GDGoalObjects1[i];
        ++k;
    }
}
gdjs.LEVEL3Code.GDGoalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects) == gdjs.evtTools.object.getPickedInstancesCount(gdjs.LEVEL3Code.mapOfGDgdjs_9546LEVEL3Code_9546GDGoalObjects1Objects));
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "WinGame");
}}

}


};gdjs.LEVEL3Code.eventsList9 = function(runtimeScene) {

{


gdjs.LEVEL3Code.eventsList0(runtimeScene);
}


{


gdjs.LEVEL3Code.eventsList2(runtimeScene);
}


{


gdjs.LEVEL3Code.eventsList6(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.LEVEL3Code.eventsList7(runtimeScene);
}


{


gdjs.LEVEL3Code.eventsList8(runtimeScene);
}


};

gdjs.LEVEL3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LEVEL3Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL3Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL3Code.GDPlayerObjects3.length = 0;
gdjs.LEVEL3Code.GDBoxObjects1.length = 0;
gdjs.LEVEL3Code.GDBoxObjects2.length = 0;
gdjs.LEVEL3Code.GDBoxObjects3.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects1.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects2.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects3.length = 0;
gdjs.LEVEL3Code.GDFloorObjects1.length = 0;
gdjs.LEVEL3Code.GDFloorObjects2.length = 0;
gdjs.LEVEL3Code.GDFloorObjects3.length = 0;
gdjs.LEVEL3Code.GDGoalObjects1.length = 0;
gdjs.LEVEL3Code.GDGoalObjects2.length = 0;
gdjs.LEVEL3Code.GDGoalObjects3.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects1.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects2.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects3.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects1.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects2.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects3.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects1.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects1.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects2.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects3.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects1.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects2.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects3.length = 0;
gdjs.LEVEL3Code.GDredboxObjects1.length = 0;
gdjs.LEVEL3Code.GDredboxObjects2.length = 0;
gdjs.LEVEL3Code.GDredboxObjects3.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects1.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects2.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects3.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects1.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects2.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects3.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects1.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects2.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects3.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects1.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects2.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects3.length = 0;

gdjs.LEVEL3Code.eventsList9(runtimeScene);
gdjs.LEVEL3Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL3Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL3Code.GDPlayerObjects3.length = 0;
gdjs.LEVEL3Code.GDBoxObjects1.length = 0;
gdjs.LEVEL3Code.GDBoxObjects2.length = 0;
gdjs.LEVEL3Code.GDBoxObjects3.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects1.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects2.length = 0;
gdjs.LEVEL3Code.GDMarkerObjects3.length = 0;
gdjs.LEVEL3Code.GDFloorObjects1.length = 0;
gdjs.LEVEL3Code.GDFloorObjects2.length = 0;
gdjs.LEVEL3Code.GDFloorObjects3.length = 0;
gdjs.LEVEL3Code.GDGoalObjects1.length = 0;
gdjs.LEVEL3Code.GDGoalObjects2.length = 0;
gdjs.LEVEL3Code.GDGoalObjects3.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects1.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects2.length = 0;
gdjs.LEVEL3Code.GDResetGameButtonObjects3.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects1.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects2.length = 0;
gdjs.LEVEL3Code.GDYouWinObjects3.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDUpKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDRightKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDLeftKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects1.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects2.length = 0;
gdjs.LEVEL3Code.GDDownKeyObjects3.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects1.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects2.length = 0;
gdjs.LEVEL3Code.GDTilemap_9595ObstaclesObjects3.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects1.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects2.length = 0;
gdjs.LEVEL3Code.GDblueboxObjects3.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects1.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects2.length = 0;
gdjs.LEVEL3Code.GDBlueTargetObjects3.length = 0;
gdjs.LEVEL3Code.GDredboxObjects1.length = 0;
gdjs.LEVEL3Code.GDredboxObjects2.length = 0;
gdjs.LEVEL3Code.GDredboxObjects3.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects1.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects2.length = 0;
gdjs.LEVEL3Code.GDredtargetObjects3.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects1.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects2.length = 0;
gdjs.LEVEL3Code.GDgreenboxObjects3.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects1.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects2.length = 0;
gdjs.LEVEL3Code.GDgreentargetObjects3.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects1.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects2.length = 0;
gdjs.LEVEL3Code.GDgreyboxObjects3.length = 0;


return;

}

gdjs['LEVEL3Code'] = gdjs.LEVEL3Code;
