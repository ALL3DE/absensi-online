gdjs.videoCode = {};
gdjs.videoCode.localVariables = [];
gdjs.videoCode.GDNewVideoObjects1= [];
gdjs.videoCode.GDNewVideoObjects2= [];


gdjs.videoCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewVideo"), gdjs.videoCode.GDNewVideoObjects1);
{for(var i = 0, len = gdjs.videoCode.GDNewVideoObjects1.length ;i < len;++i) {
    gdjs.videoCode.GDNewVideoObjects1[i].play();
}
}}

}


};

gdjs.videoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.videoCode.GDNewVideoObjects1.length = 0;
gdjs.videoCode.GDNewVideoObjects2.length = 0;

gdjs.videoCode.eventsList0(runtimeScene);
gdjs.videoCode.GDNewVideoObjects1.length = 0;
gdjs.videoCode.GDNewVideoObjects2.length = 0;


return;

}

gdjs['videoCode'] = gdjs.videoCode;
