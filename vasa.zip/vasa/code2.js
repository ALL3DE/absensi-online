gdjs.LEVEL2Code = {};
gdjs.LEVEL2Code.localVariables = [];
gdjs.LEVEL2Code.GDPlayerObjects1= [];
gdjs.LEVEL2Code.GDPlayerObjects2= [];
gdjs.LEVEL2Code.GDPlayerObjects3= [];
gdjs.LEVEL2Code.GDPlayerObjects4= [];
gdjs.LEVEL2Code.GDPlatform1Objects1= [];
gdjs.LEVEL2Code.GDPlatform1Objects2= [];
gdjs.LEVEL2Code.GDPlatform1Objects3= [];
gdjs.LEVEL2Code.GDPlatform1Objects4= [];
gdjs.LEVEL2Code.GDPlatform2Objects1= [];
gdjs.LEVEL2Code.GDPlatform2Objects2= [];
gdjs.LEVEL2Code.GDPlatform2Objects3= [];
gdjs.LEVEL2Code.GDPlatform2Objects4= [];
gdjs.LEVEL2Code.GDPlatform3Objects1= [];
gdjs.LEVEL2Code.GDPlatform3Objects2= [];
gdjs.LEVEL2Code.GDPlatform3Objects3= [];
gdjs.LEVEL2Code.GDPlatform3Objects4= [];
gdjs.LEVEL2Code.GDPlatform4Objects1= [];
gdjs.LEVEL2Code.GDPlatform4Objects2= [];
gdjs.LEVEL2Code.GDPlatform4Objects3= [];
gdjs.LEVEL2Code.GDPlatform4Objects4= [];
gdjs.LEVEL2Code.GDPortalObjects1= [];
gdjs.LEVEL2Code.GDPortalObjects2= [];
gdjs.LEVEL2Code.GDPortalObjects3= [];
gdjs.LEVEL2Code.GDPortalObjects4= [];
gdjs.LEVEL2Code.GDCheckpointObjects1= [];
gdjs.LEVEL2Code.GDCheckpointObjects2= [];
gdjs.LEVEL2Code.GDCheckpointObjects3= [];
gdjs.LEVEL2Code.GDCheckpointObjects4= [];
gdjs.LEVEL2Code.GDLadderObjects1= [];
gdjs.LEVEL2Code.GDLadderObjects2= [];
gdjs.LEVEL2Code.GDLadderObjects3= [];
gdjs.LEVEL2Code.GDLadderObjects4= [];
gdjs.LEVEL2Code.GDMonsterObjects1= [];
gdjs.LEVEL2Code.GDMonsterObjects2= [];
gdjs.LEVEL2Code.GDMonsterObjects3= [];
gdjs.LEVEL2Code.GDMonsterObjects4= [];
gdjs.LEVEL2Code.GDFlyObjects1= [];
gdjs.LEVEL2Code.GDFlyObjects2= [];
gdjs.LEVEL2Code.GDFlyObjects3= [];
gdjs.LEVEL2Code.GDFlyObjects4= [];
gdjs.LEVEL2Code.GDCoinObjects1= [];
gdjs.LEVEL2Code.GDCoinObjects2= [];
gdjs.LEVEL2Code.GDCoinObjects3= [];
gdjs.LEVEL2Code.GDCoinObjects4= [];
gdjs.LEVEL2Code.GDMonsterParticlesObjects1= [];
gdjs.LEVEL2Code.GDMonsterParticlesObjects2= [];
gdjs.LEVEL2Code.GDMonsterParticlesObjects3= [];
gdjs.LEVEL2Code.GDMonsterParticlesObjects4= [];
gdjs.LEVEL2Code.GDCoinParticlesObjects1= [];
gdjs.LEVEL2Code.GDCoinParticlesObjects2= [];
gdjs.LEVEL2Code.GDCoinParticlesObjects3= [];
gdjs.LEVEL2Code.GDCoinParticlesObjects4= [];
gdjs.LEVEL2Code.GDDoorParticlesObjects1= [];
gdjs.LEVEL2Code.GDDoorParticlesObjects2= [];
gdjs.LEVEL2Code.GDDoorParticlesObjects3= [];
gdjs.LEVEL2Code.GDDoorParticlesObjects4= [];
gdjs.LEVEL2Code.GDDustParticleObjects1= [];
gdjs.LEVEL2Code.GDDustParticleObjects2= [];
gdjs.LEVEL2Code.GDDustParticleObjects3= [];
gdjs.LEVEL2Code.GDDustParticleObjects4= [];
gdjs.LEVEL2Code.GDCloudsObjects1= [];
gdjs.LEVEL2Code.GDCloudsObjects2= [];
gdjs.LEVEL2Code.GDCloudsObjects3= [];
gdjs.LEVEL2Code.GDCloudsObjects4= [];
gdjs.LEVEL2Code.GDScoreTextObjects1= [];
gdjs.LEVEL2Code.GDScoreTextObjects2= [];
gdjs.LEVEL2Code.GDScoreTextObjects3= [];
gdjs.LEVEL2Code.GDScoreTextObjects4= [];
gdjs.LEVEL2Code.GDBackgroundPlantsObjects1= [];
gdjs.LEVEL2Code.GDBackgroundPlantsObjects2= [];
gdjs.LEVEL2Code.GDBackgroundPlantsObjects3= [];
gdjs.LEVEL2Code.GDBackgroundPlantsObjects4= [];
gdjs.LEVEL2Code.GDLeftBoundaryObjects1= [];
gdjs.LEVEL2Code.GDLeftBoundaryObjects2= [];
gdjs.LEVEL2Code.GDLeftBoundaryObjects3= [];
gdjs.LEVEL2Code.GDLeftBoundaryObjects4= [];
gdjs.LEVEL2Code.GDRightBoundaryObjects1= [];
gdjs.LEVEL2Code.GDRightBoundaryObjects2= [];
gdjs.LEVEL2Code.GDRightBoundaryObjects3= [];
gdjs.LEVEL2Code.GDRightBoundaryObjects4= [];
gdjs.LEVEL2Code.GDTopBoundaryObjects1= [];
gdjs.LEVEL2Code.GDTopBoundaryObjects2= [];
gdjs.LEVEL2Code.GDTopBoundaryObjects3= [];
gdjs.LEVEL2Code.GDTopBoundaryObjects4= [];
gdjs.LEVEL2Code.GDBottomBoundaryObjects1= [];
gdjs.LEVEL2Code.GDBottomBoundaryObjects2= [];
gdjs.LEVEL2Code.GDBottomBoundaryObjects3= [];
gdjs.LEVEL2Code.GDBottomBoundaryObjects4= [];
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects1= [];
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects2= [];
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3= [];
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects4= [];
gdjs.LEVEL2Code.GDMoonObjects1= [];
gdjs.LEVEL2Code.GDMoonObjects2= [];
gdjs.LEVEL2Code.GDMoonObjects3= [];
gdjs.LEVEL2Code.GDMoonObjects4= [];
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects1= [];
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2= [];
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects3= [];
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects4= [];
gdjs.LEVEL2Code.GDEndScreenHeaderObjects1= [];
gdjs.LEVEL2Code.GDEndScreenHeaderObjects2= [];
gdjs.LEVEL2Code.GDEndScreenHeaderObjects3= [];
gdjs.LEVEL2Code.GDEndScreenHeaderObjects4= [];
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects1= [];
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2= [];
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3= [];
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects4= [];
gdjs.LEVEL2Code.GDEndScreenBestTextObjects1= [];
gdjs.LEVEL2Code.GDEndScreenBestTextObjects2= [];
gdjs.LEVEL2Code.GDEndScreenBestTextObjects3= [];
gdjs.LEVEL2Code.GDEndScreenBestTextObjects4= [];
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects1= [];
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2= [];
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects3= [];
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects4= [];
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects1= [];
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2= [];
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects3= [];
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects4= [];
gdjs.LEVEL2Code.GDRetryButtonObjects1= [];
gdjs.LEVEL2Code.GDRetryButtonObjects2= [];
gdjs.LEVEL2Code.GDRetryButtonObjects3= [];
gdjs.LEVEL2Code.GDRetryButtonObjects4= [];
gdjs.LEVEL2Code.GDJoystickObjects1= [];
gdjs.LEVEL2Code.GDJoystickObjects2= [];
gdjs.LEVEL2Code.GDJoystickObjects3= [];
gdjs.LEVEL2Code.GDJoystickObjects4= [];
gdjs.LEVEL2Code.GDJumpButtonObjects1= [];
gdjs.LEVEL2Code.GDJumpButtonObjects2= [];
gdjs.LEVEL2Code.GDJumpButtonObjects3= [];
gdjs.LEVEL2Code.GDJumpButtonObjects4= [];
gdjs.LEVEL2Code.GDPixelHeartBarObjects1= [];
gdjs.LEVEL2Code.GDPixelHeartBarObjects2= [];
gdjs.LEVEL2Code.GDPixelHeartBarObjects3= [];
gdjs.LEVEL2Code.GDPixelHeartBarObjects4= [];


gdjs.LEVEL2Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LEVEL2Code.GDJumpButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDJumpButtonObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDJumpButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDJumpButtonObjects3[k] = gdjs.LEVEL2Code.GDJumpButtonObjects3[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDJumpButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20800580);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDJumpButtonObjects3 */
{for(var i = 0, len = gdjs.LEVEL2Code.GDJumpButtonObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDJumpButtonObjects3[i].setColor("74;74;74");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LEVEL2Code.GDJumpButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDJumpButtonObjects2.length;i<l;++i) {
    if ( !(gdjs.LEVEL2Code.GDJumpButtonObjects2[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDJumpButtonObjects2[k] = gdjs.LEVEL2Code.GDJumpButtonObjects2[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDJumpButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20801964);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDJumpButtonObjects2 */
{for(var i = 0, len = gdjs.LEVEL2Code.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDJumpButtonObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.LEVEL2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.LEVEL2Code.GDJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LEVEL2Code.GDJumpButtonObjects1);
{for(var i = 0, len = gdjs.LEVEL2Code.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDJumpButtonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.LEVEL2Code.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LEVEL2Code.eventsList2 = function(runtimeScene) {

{



}


{


gdjs.LEVEL2Code.eventsList1(runtimeScene);
}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDDustParticleObjects2Objects = Hashtable.newFrom({"DustParticle": gdjs.LEVEL2Code.GDDustParticleObjects2});
gdjs.LEVEL2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects3[k] = gdjs.LEVEL2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20804188);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump2.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Player__IsSteppingOnFloor.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20805380);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */
gdjs.LEVEL2Code.GDDustParticleObjects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "grass2.mp3", 1, false, 20, gdjs.randomFloatInRange(0.7, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDDustParticleObjects2Objects, (( gdjs.LEVEL2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDPlayerObjects2[0].getAABBCenterX()), (( gdjs.LEVEL2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDPlayerObjects2[0].getAABBBottom()), "");
}{for(var i = 0, len = gdjs.LEVEL2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDDustParticleObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.LEVEL2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDDustParticleObjects2[i].setAngle(270);
}
}}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects3});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.LEVEL2Code.GDCheckpointObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCheckpointObjects3Objects = Hashtable.newFrom({"Checkpoint": gdjs.LEVEL2Code.GDCheckpointObjects3});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LEVEL2Code.GDCheckpointObjects2, gdjs.LEVEL2Code.GDCheckpointObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCheckpointObjects3Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDCheckpointObjects3 */
{for(var i = 0, len = gdjs.LEVEL2Code.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDCheckpointObjects3[i].getBehavior("Animation").setAnimationName("InActive");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LEVEL2Code.GDCheckpointObjects2 */
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, (( gdjs.LEVEL2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDCheckpointObjects2[0].getPointX("")), (( gdjs.LEVEL2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDCheckpointObjects2[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDCheckpointObjects2[i].getBehavior("Animation").setAnimationName("Activate");
}
}}

}


};gdjs.LEVEL2Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects3);
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects3Objects, (( gdjs.LEVEL2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.LEVEL2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDPlayerObjects3[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.LEVEL2Code.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCheckpointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDCheckpointObjects2.length;i<l;++i) {
    if ( !(gdjs.LEVEL2Code.GDCheckpointObjects2[i].getBehavior("Animation").getAnimationName() == "Activate") ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDCheckpointObjects2[k] = gdjs.LEVEL2Code.GDCheckpointObjects2[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDCheckpointObjects2.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint2.mp3", false, 50, 1);
}
{ //Subevents
gdjs.LEVEL2Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.LEVEL2Code.GDCoinObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.LEVEL2Code.GDCoinParticlesObjects2});
gdjs.LEVEL2Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.LEVEL2Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDCoinObjects2 */
gdjs.LEVEL2Code.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDCoinParticlesObjects2Objects, (( gdjs.LEVEL2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.LEVEL2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.LEVEL2Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin2.mp3", false, 50, 1);
}}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects1});
gdjs.LEVEL2Code.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDPlayerObjects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects1[k] = gdjs.LEVEL2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects1 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LEVEL2Code.eventsList8 = function(runtimeScene) {

{


gdjs.LEVEL2Code.eventsList3(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList5(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList6(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList7(runtimeScene);
}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LEVEL2Code.GDFlyObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.LEVEL2Code.GDFlyObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects3Objects = Hashtable.newFrom({"Fly": gdjs.LEVEL2Code.GDFlyObjects3});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects3});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LEVEL2Code.GDPlayerObjects2, gdjs.LEVEL2Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects3[k] = gdjs.LEVEL2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LEVEL2Code.GDFlyObjects2, gdjs.LEVEL2Code.GDFlyObjects3);

/* Reuse gdjs.LEVEL2Code.GDPlayerObjects3 */
{gdjs.evtsExt__Enemy__TriggerFlyDeath.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects3Objects, "RectangleMovement", "ShakeObject_PositionAngle", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects3Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.LEVEL2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects2[k] = gdjs.LEVEL2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LEVEL2Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.LEVEL2Code.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__Enemy__IsFlyDead.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDFlyObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.LEVEL2Code.GDBackgroundPlantsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.LEVEL2Code.GDFlyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDFlyObjects1[i].getY() > (( gdjs.LEVEL2Code.GDBackgroundPlantsObjects1.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDBackgroundPlantsObjects1[0].getAABBBottom()) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDFlyObjects1[k] = gdjs.LEVEL2Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDFlyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDFlyObjects1 */
{for(var i = 0, len = gdjs.LEVEL2Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects1});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDMonsterObjects1Objects = Hashtable.newFrom({"Monster": gdjs.LEVEL2Code.GDMonsterObjects1});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDMonsterParticlesObjects2Objects = Hashtable.newFrom({"MonsterParticles": gdjs.LEVEL2Code.GDMonsterParticlesObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects1});
gdjs.LEVEL2Code.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.LEVEL2Code.GDPlayerObjects1, gdjs.LEVEL2Code.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects2[k] = gdjs.LEVEL2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LEVEL2Code.GDMonsterObjects1, gdjs.LEVEL2Code.GDMonsterObjects2);

/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */
gdjs.LEVEL2Code.GDMonsterParticlesObjects2.length = 0;

{for(var i = 0, len = gdjs.LEVEL2Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDMonsterObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDMonsterParticlesObjects2Objects, (( gdjs.LEVEL2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDMonsterObjects2[0].getCenterXInScene()), (( gdjs.LEVEL2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDMonsterObjects2[0].getCenterYInScene()), "");
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.LEVEL2Code.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.LEVEL2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPlayerObjects1[k] = gdjs.LEVEL2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects1 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LEVEL2Code.eventsList12 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.LEVEL2Code.GDMonsterObjects1, gdjs.LEVEL2Code.GDMonsterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDMonsterObjects2[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDMonsterObjects2[k] = gdjs.LEVEL2Code.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDMonsterObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.LEVEL2Code.GDPlayerObjects1, gdjs.LEVEL2Code.GDPlayerObjects2);

{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

/* Reuse gdjs.LEVEL2Code.GDMonsterObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDMonsterObjects1.length;i<l;++i) {
    if ( !(gdjs.LEVEL2Code.GDMonsterObjects1[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDMonsterObjects1[k] = gdjs.LEVEL2Code.GDMonsterObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDMonsterObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL2Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.LEVEL2Code.GDMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDMonsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LEVEL2Code.GDPortalObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects2});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.LEVEL2Code.GDPortalObjects2});
gdjs.LEVEL2Code.eventsList14 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.LEVEL2Code.GDPlayerObjects2 */
/* Reuse gdjs.LEVEL2Code.GDPortalObjects2 */
{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects2[i].activateBehavior("PlatformerObject", false);
}
}{gdjs.evtsExt__Player__AnimateFallingIntoPortal.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, "Tween", gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LEVEL2Code.eventsList15 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3);
{for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3[i].getBehavior("Text").setText("You got " + runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() + " points!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LEVEL2Code.GDEndScreenBestTextObjects3);
{for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenBestTextObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenBestTextObjects3[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2);
{for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2[i].hide();
}
}}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDEndScreenBackgroundObjects2Objects = Hashtable.newFrom({"EndScreenBackground": gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2});
gdjs.LEVEL2Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14471836);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList15(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.LEVEL2Code.GDEndScreenBestTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenHeader"), gdjs.LEVEL2Code.GDEndScreenHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LEVEL2Code.GDRetryButtonObjects2);
{gdjs.evtsExt__UserInterface__StretchToFillScreen.func(runtimeScene, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDEndScreenBackgroundObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenHeaderObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenBestTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.LEVEL2Code.GDRetryButtonObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDRetryButtonObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.LEVEL2Code.GDRetryButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDRetryButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDRetryButtonObjects1[k] = gdjs.LEVEL2Code.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDRetryButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


};gdjs.LEVEL2Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
if (isConditionTrue_0) {

{ //Subevents
gdjs.LEVEL2Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL2Code.eventsList18 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2[i].getBehavior("Opacity").setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.LEVEL2Code.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects2Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20765076);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}
{ //Subevents
gdjs.LEVEL2Code.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.LEVEL2Code.eventsList17(runtimeScene);
}


};gdjs.LEVEL2Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoundaryJumpThrough"), gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.LEVEL2Code.GDLeftBoundaryObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.LEVEL2Code.GDRightBoundaryObjects3);
{for(var i = 0, len = gdjs.LEVEL2Code.GDLeftBoundaryObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDLeftBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.LEVEL2Code.GDRightBoundaryObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDRightBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.LEVEL2Code.GDBackgroundPlantsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Moon"), gdjs.LEVEL2Code.GDMoonObjects3);
{for(var i = 0, len = gdjs.LEVEL2Code.GDMoonObjects3.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDMoonObjects3[i].setPosition(0.9 * gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) - (( gdjs.LEVEL2Code.GDBackgroundPlantsObjects3.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDBackgroundPlantsObjects3[0].getXOffset()),100 - (( gdjs.LEVEL2Code.GDBackgroundPlantsObjects3.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDBackgroundPlantsObjects3[0].getYOffset()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.LEVEL2Code.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.LEVEL2Code.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.LEVEL2Code.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.LEVEL2Code.GDTopBoundaryObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.LEVEL2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDLeftBoundaryObjects2[0].getPointX("")) + (( gdjs.LEVEL2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDLeftBoundaryObjects2[0].getWidth()), (( gdjs.LEVEL2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDTopBoundaryObjects2[0].getPointY("")) + (( gdjs.LEVEL2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDTopBoundaryObjects2[0].getHeight()), (( gdjs.LEVEL2Code.GDRightBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDRightBoundaryObjects2[0].getPointX("")), (( gdjs.LEVEL2Code.GDBottomBoundaryObjects2.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDBottomBoundaryObjects2[0].getPointY("")), "", 0);
}}

}


};gdjs.LEVEL2Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.LEVEL2Code.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.LEVEL2Code.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDScoreTextObjects2[i].getBehavior("Text").setText("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.LEVEL2Code.GDPortalObjects1});
gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL2Code.GDPlayerObjects1});
gdjs.LEVEL2Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets2.aac", true, 30, 1);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "door2.aac", 0, true, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.LEVEL2Code.GDPortalObjects1);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPortalObjects1Objects, gdjs.LEVEL2Code.mapOfGDgdjs_9546LEVEL2Code_9546GDPlayerObjects1Objects, 0, 20, 750, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LEVEL2Code.eventsList22 = function(runtimeScene) {

{


gdjs.LEVEL2Code.eventsList19(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList20(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList21(runtimeScene);
}


};gdjs.LEVEL2Code.eventsList23 = function(runtimeScene) {

{



}


{


gdjs.LEVEL2Code.eventsList2(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList8(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList10(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList13(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList18(runtimeScene);
}


{


gdjs.LEVEL2Code.eventsList22(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LEVEL2Code.GDPixelHeartBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL2Code.GDPixelHeartBarObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPixelHeartBarObjects1[i].SetValue((( gdjs.LEVEL2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.LEVEL2Code.GDPlayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PixelHeartBar"), gdjs.LEVEL2Code.GDPixelHeartBarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL2Code.GDPixelHeartBarObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL2Code.GDPixelHeartBarObjects1[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL2Code.GDPixelHeartBarObjects1[k] = gdjs.LEVEL2Code.GDPixelHeartBarObjects1[i];
        ++k;
    }
}
gdjs.LEVEL2Code.GDPixelHeartBarObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL2Code.GDPlayerObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.LEVEL2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL2Code.GDPlayerObjects1[i].activateBehavior("PlatformerObject", false);
}
}}

}


};

gdjs.LEVEL2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LEVEL2Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects3.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects4.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects4.length = 0;
gdjs.LEVEL2Code.GDPortalObjects1.length = 0;
gdjs.LEVEL2Code.GDPortalObjects2.length = 0;
gdjs.LEVEL2Code.GDPortalObjects3.length = 0;
gdjs.LEVEL2Code.GDPortalObjects4.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects1.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects2.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects3.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects4.length = 0;
gdjs.LEVEL2Code.GDLadderObjects1.length = 0;
gdjs.LEVEL2Code.GDLadderObjects2.length = 0;
gdjs.LEVEL2Code.GDLadderObjects3.length = 0;
gdjs.LEVEL2Code.GDLadderObjects4.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects1.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects2.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects3.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects4.length = 0;
gdjs.LEVEL2Code.GDFlyObjects1.length = 0;
gdjs.LEVEL2Code.GDFlyObjects2.length = 0;
gdjs.LEVEL2Code.GDFlyObjects3.length = 0;
gdjs.LEVEL2Code.GDFlyObjects4.length = 0;
gdjs.LEVEL2Code.GDCoinObjects1.length = 0;
gdjs.LEVEL2Code.GDCoinObjects2.length = 0;
gdjs.LEVEL2Code.GDCoinObjects3.length = 0;
gdjs.LEVEL2Code.GDCoinObjects4.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects1.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects2.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects3.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects4.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects1.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects2.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects3.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects4.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects1.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects2.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects3.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects4.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects1.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects2.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects3.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects4.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.LEVEL2Code.GDMoonObjects1.length = 0;
gdjs.LEVEL2Code.GDMoonObjects2.length = 0;
gdjs.LEVEL2Code.GDMoonObjects3.length = 0;
gdjs.LEVEL2Code.GDMoonObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects4.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects1.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects2.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects3.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects4.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects1.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects2.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects3.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects4.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects1.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects2.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects3.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects4.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects1.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects2.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects3.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects4.length = 0;

gdjs.LEVEL2Code.eventsList23(runtimeScene);
gdjs.LEVEL2Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects3.length = 0;
gdjs.LEVEL2Code.GDPlayerObjects4.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform1Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform2Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform3Objects4.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects1.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects2.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects3.length = 0;
gdjs.LEVEL2Code.GDPlatform4Objects4.length = 0;
gdjs.LEVEL2Code.GDPortalObjects1.length = 0;
gdjs.LEVEL2Code.GDPortalObjects2.length = 0;
gdjs.LEVEL2Code.GDPortalObjects3.length = 0;
gdjs.LEVEL2Code.GDPortalObjects4.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects1.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects2.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects3.length = 0;
gdjs.LEVEL2Code.GDCheckpointObjects4.length = 0;
gdjs.LEVEL2Code.GDLadderObjects1.length = 0;
gdjs.LEVEL2Code.GDLadderObjects2.length = 0;
gdjs.LEVEL2Code.GDLadderObjects3.length = 0;
gdjs.LEVEL2Code.GDLadderObjects4.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects1.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects2.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects3.length = 0;
gdjs.LEVEL2Code.GDMonsterObjects4.length = 0;
gdjs.LEVEL2Code.GDFlyObjects1.length = 0;
gdjs.LEVEL2Code.GDFlyObjects2.length = 0;
gdjs.LEVEL2Code.GDFlyObjects3.length = 0;
gdjs.LEVEL2Code.GDFlyObjects4.length = 0;
gdjs.LEVEL2Code.GDCoinObjects1.length = 0;
gdjs.LEVEL2Code.GDCoinObjects2.length = 0;
gdjs.LEVEL2Code.GDCoinObjects3.length = 0;
gdjs.LEVEL2Code.GDCoinObjects4.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDMonsterParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDCoinParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects1.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects2.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects3.length = 0;
gdjs.LEVEL2Code.GDDoorParticlesObjects4.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects1.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects2.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects3.length = 0;
gdjs.LEVEL2Code.GDDustParticleObjects4.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects1.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects2.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects3.length = 0;
gdjs.LEVEL2Code.GDCloudsObjects4.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects1.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects2.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects3.length = 0;
gdjs.LEVEL2Code.GDScoreTextObjects4.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects1.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects2.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects3.length = 0;
gdjs.LEVEL2Code.GDBackgroundPlantsObjects4.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDLeftBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDRightBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDTopBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects1.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects2.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects3.length = 0;
gdjs.LEVEL2Code.GDBottomBoundaryObjects4.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.LEVEL2Code.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.LEVEL2Code.GDMoonObjects1.length = 0;
gdjs.LEVEL2Code.GDMoonObjects2.length = 0;
gdjs.LEVEL2Code.GDMoonObjects3.length = 0;
gdjs.LEVEL2Code.GDMoonObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenBackgroundObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenHeaderObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenBestTextObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects1.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects2.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects3.length = 0;
gdjs.LEVEL2Code.GDEndScreenRetryTextObjects4.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects1.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects2.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects3.length = 0;
gdjs.LEVEL2Code.GDRetryButtonObjects4.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects1.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects2.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects3.length = 0;
gdjs.LEVEL2Code.GDJoystickObjects4.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects1.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects2.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects3.length = 0;
gdjs.LEVEL2Code.GDJumpButtonObjects4.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects1.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects2.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects3.length = 0;
gdjs.LEVEL2Code.GDPixelHeartBarObjects4.length = 0;


return;

}

gdjs['LEVEL2Code'] = gdjs.LEVEL2Code;
