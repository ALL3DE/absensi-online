gdjs.LEVEL1Code = {};
gdjs.LEVEL1Code.localVariables = [];
gdjs.LEVEL1Code.forEachIndex2 = 0;

gdjs.LEVEL1Code.forEachObjects2 = [];

gdjs.LEVEL1Code.forEachTemporary2 = null;

gdjs.LEVEL1Code.forEachTotalCount2 = 0;

gdjs.LEVEL1Code.GDCrabCardObjects1= [];
gdjs.LEVEL1Code.GDCrabCardObjects2= [];
gdjs.LEVEL1Code.GDCrabCardObjects3= [];
gdjs.LEVEL1Code.GDCrabCardObjects4= [];
gdjs.LEVEL1Code.GDCrabCardObjects5= [];
gdjs.LEVEL1Code.GDSnailCardObjects1= [];
gdjs.LEVEL1Code.GDSnailCardObjects2= [];
gdjs.LEVEL1Code.GDSnailCardObjects3= [];
gdjs.LEVEL1Code.GDSnailCardObjects4= [];
gdjs.LEVEL1Code.GDSnailCardObjects5= [];
gdjs.LEVEL1Code.GDSeagrassCardObjects1= [];
gdjs.LEVEL1Code.GDSeagrassCardObjects2= [];
gdjs.LEVEL1Code.GDSeagrassCardObjects3= [];
gdjs.LEVEL1Code.GDSeagrassCardObjects4= [];
gdjs.LEVEL1Code.GDSeagrassCardObjects5= [];
gdjs.LEVEL1Code.GDCoralCardObjects1= [];
gdjs.LEVEL1Code.GDCoralCardObjects2= [];
gdjs.LEVEL1Code.GDCoralCardObjects3= [];
gdjs.LEVEL1Code.GDCoralCardObjects4= [];
gdjs.LEVEL1Code.GDCoralCardObjects5= [];
gdjs.LEVEL1Code.GDAnemoneCardObjects1= [];
gdjs.LEVEL1Code.GDAnemoneCardObjects2= [];
gdjs.LEVEL1Code.GDAnemoneCardObjects3= [];
gdjs.LEVEL1Code.GDAnemoneCardObjects4= [];
gdjs.LEVEL1Code.GDAnemoneCardObjects5= [];
gdjs.LEVEL1Code.GDPlasticBagCardObjects1= [];
gdjs.LEVEL1Code.GDPlasticBagCardObjects2= [];
gdjs.LEVEL1Code.GDPlasticBagCardObjects3= [];
gdjs.LEVEL1Code.GDPlasticBagCardObjects4= [];
gdjs.LEVEL1Code.GDPlasticBagCardObjects5= [];
gdjs.LEVEL1Code.GDBlowfishCardObjects1= [];
gdjs.LEVEL1Code.GDBlowfishCardObjects2= [];
gdjs.LEVEL1Code.GDBlowfishCardObjects3= [];
gdjs.LEVEL1Code.GDBlowfishCardObjects4= [];
gdjs.LEVEL1Code.GDBlowfishCardObjects5= [];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects1= [];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects2= [];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects3= [];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects4= [];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects5= [];
gdjs.LEVEL1Code.GDBoardObjects1= [];
gdjs.LEVEL1Code.GDBoardObjects2= [];
gdjs.LEVEL1Code.GDBoardObjects3= [];
gdjs.LEVEL1Code.GDBoardObjects4= [];
gdjs.LEVEL1Code.GDBoardObjects5= [];
gdjs.LEVEL1Code.GDPairsObjects1= [];
gdjs.LEVEL1Code.GDPairsObjects2= [];
gdjs.LEVEL1Code.GDPairsObjects3= [];
gdjs.LEVEL1Code.GDPairsObjects4= [];
gdjs.LEVEL1Code.GDPairsObjects5= [];
gdjs.LEVEL1Code.GDNewGameObjects1= [];
gdjs.LEVEL1Code.GDNewGameObjects2= [];
gdjs.LEVEL1Code.GDNewGameObjects3= [];
gdjs.LEVEL1Code.GDNewGameObjects4= [];
gdjs.LEVEL1Code.GDNewGameObjects5= [];
gdjs.LEVEL1Code.GDYouWonObjects1= [];
gdjs.LEVEL1Code.GDYouWonObjects2= [];
gdjs.LEVEL1Code.GDYouWonObjects3= [];
gdjs.LEVEL1Code.GDYouWonObjects4= [];
gdjs.LEVEL1Code.GDYouWonObjects5= [];
gdjs.LEVEL1Code.GDStarParticleObjects1= [];
gdjs.LEVEL1Code.GDStarParticleObjects2= [];
gdjs.LEVEL1Code.GDStarParticleObjects3= [];
gdjs.LEVEL1Code.GDStarParticleObjects4= [];
gdjs.LEVEL1Code.GDStarParticleObjects5= [];
gdjs.LEVEL1Code.GDScreenFadeObjects1= [];
gdjs.LEVEL1Code.GDScreenFadeObjects2= [];
gdjs.LEVEL1Code.GDScreenFadeObjects3= [];
gdjs.LEVEL1Code.GDScreenFadeObjects4= [];
gdjs.LEVEL1Code.GDScreenFadeObjects5= [];
gdjs.LEVEL1Code.GDBlackBackgroundObjects1= [];
gdjs.LEVEL1Code.GDBlackBackgroundObjects2= [];
gdjs.LEVEL1Code.GDBlackBackgroundObjects3= [];
gdjs.LEVEL1Code.GDBlackBackgroundObjects4= [];
gdjs.LEVEL1Code.GDBlackBackgroundObjects5= [];
gdjs.LEVEL1Code.GDSelectionObjects1= [];
gdjs.LEVEL1Code.GDSelectionObjects2= [];
gdjs.LEVEL1Code.GDSelectionObjects3= [];
gdjs.LEVEL1Code.GDSelectionObjects4= [];
gdjs.LEVEL1Code.GDSelectionObjects5= [];
gdjs.LEVEL1Code.GDNewgameButtonObjects1= [];
gdjs.LEVEL1Code.GDNewgameButtonObjects2= [];
gdjs.LEVEL1Code.GDNewgameButtonObjects3= [];
gdjs.LEVEL1Code.GDNewgameButtonObjects4= [];
gdjs.LEVEL1Code.GDNewgameButtonObjects5= [];
gdjs.LEVEL1Code.GDNewTiledSpriteObjects1= [];
gdjs.LEVEL1Code.GDNewTiledSpriteObjects2= [];
gdjs.LEVEL1Code.GDNewTiledSpriteObjects3= [];
gdjs.LEVEL1Code.GDNewTiledSpriteObjects4= [];
gdjs.LEVEL1Code.GDNewTiledSpriteObjects5= [];
gdjs.LEVEL1Code.GDsamlongObjects1= [];
gdjs.LEVEL1Code.GDsamlongObjects2= [];
gdjs.LEVEL1Code.GDsamlongObjects3= [];
gdjs.LEVEL1Code.GDsamlongObjects4= [];
gdjs.LEVEL1Code.GDsamlongObjects5= [];
gdjs.LEVEL1Code.GDGroundTileObjects1= [];
gdjs.LEVEL1Code.GDGroundTileObjects2= [];
gdjs.LEVEL1Code.GDGroundTileObjects3= [];
gdjs.LEVEL1Code.GDGroundTileObjects4= [];
gdjs.LEVEL1Code.GDGroundTileObjects5= [];
gdjs.LEVEL1Code.GDCloseButtonObjects1= [];
gdjs.LEVEL1Code.GDCloseButtonObjects2= [];
gdjs.LEVEL1Code.GDCloseButtonObjects3= [];
gdjs.LEVEL1Code.GDCloseButtonObjects4= [];
gdjs.LEVEL1Code.GDCloseButtonObjects5= [];
gdjs.LEVEL1Code.GDpetunjukObjects1= [];
gdjs.LEVEL1Code.GDpetunjukObjects2= [];
gdjs.LEVEL1Code.GDpetunjukObjects3= [];
gdjs.LEVEL1Code.GDpetunjukObjects4= [];
gdjs.LEVEL1Code.GDpetunjukObjects5= [];
gdjs.LEVEL1Code.GDwaktuObjects1= [];
gdjs.LEVEL1Code.GDwaktuObjects2= [];
gdjs.LEVEL1Code.GDwaktuObjects3= [];
gdjs.LEVEL1Code.GDwaktuObjects4= [];
gdjs.LEVEL1Code.GDwaktuObjects5= [];
gdjs.LEVEL1Code.GDgame_9595overObjects1= [];
gdjs.LEVEL1Code.GDgame_9595overObjects2= [];
gdjs.LEVEL1Code.GDgame_9595overObjects3= [];
gdjs.LEVEL1Code.GDgame_9595overObjects4= [];
gdjs.LEVEL1Code.GDgame_9595overObjects5= [];
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1= [];
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects2= [];
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects3= [];
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects4= [];
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects5= [];
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1= [];
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects2= [];
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects3= [];
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects4= [];
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects5= [];


gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects2Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects2, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects2, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects2, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects2, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects2, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects2, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects2, "samlong": gdjs.LEVEL1Code.GDsamlongObjects2});
gdjs.LEVEL1Code.eventsList0 = function(runtimeScene) {

};gdjs.LEVEL1Code.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("PositionPlaceholder"), gdjs.LEVEL1Code.GDPositionPlaceholderObjects1);

for (gdjs.LEVEL1Code.forEachIndex2 = 0;gdjs.LEVEL1Code.forEachIndex2 < gdjs.LEVEL1Code.GDPositionPlaceholderObjects1.length;++gdjs.LEVEL1Code.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("AnemoneCard"), gdjs.LEVEL1Code.GDAnemoneCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlowfishCard"), gdjs.LEVEL1Code.GDBlowfishCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("CoralCard"), gdjs.LEVEL1Code.GDCoralCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("CrabCard"), gdjs.LEVEL1Code.GDCrabCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlasticBagCard"), gdjs.LEVEL1Code.GDPlasticBagCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("SeagrassCard"), gdjs.LEVEL1Code.GDSeagrassCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("SnailCard"), gdjs.LEVEL1Code.GDSnailCardObjects2);
gdjs.copyArray(runtimeScene.getObjects("samlong"), gdjs.LEVEL1Code.GDsamlongObjects2);
gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length = 0;


gdjs.LEVEL1Code.forEachTemporary2 = gdjs.LEVEL1Code.GDPositionPlaceholderObjects1[gdjs.LEVEL1Code.forEachIndex2];
gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.push(gdjs.LEVEL1Code.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDBlowfishCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDBlowfishCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDBlowfishCardObjects2[k] = gdjs.LEVEL1Code.GDBlowfishCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDBlowfishCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCrabCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCrabCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCrabCardObjects2[k] = gdjs.LEVEL1Code.GDCrabCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCrabCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSnailCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSnailCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSnailCardObjects2[k] = gdjs.LEVEL1Code.GDSnailCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSnailCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSeagrassCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSeagrassCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSeagrassCardObjects2[k] = gdjs.LEVEL1Code.GDSeagrassCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSeagrassCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCoralCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCoralCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCoralCardObjects2[k] = gdjs.LEVEL1Code.GDCoralCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCoralCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDAnemoneCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDAnemoneCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDAnemoneCardObjects2[k] = gdjs.LEVEL1Code.GDAnemoneCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDAnemoneCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDPlasticBagCardObjects2[k] = gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDsamlongObjects2.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDsamlongObjects2[i].getBehavior("Animation").getAnimationName() == "Front" ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDsamlongObjects2[k] = gdjs.LEVEL1Code.GDsamlongObjects2[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDsamlongObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects2Objects);
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects2[i].getBehavior("Tween").addObjectPositionTween2("FlyIn", (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointX("")), (( gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length === 0 ) ? 0 :gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[0].getPointY("")), "easeOutSine", 1, false);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects2[i].getBehavior("Animation").setAnimationName("Back");
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPositionPlaceholderObjects2[i].deleteFromScene(runtimeScene);
}
}}
}

}


};gdjs.LEVEL1Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ScreenFade"), gdjs.LEVEL1Code.GDScreenFadeObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Fade");
}{for(var i = 0, len = gdjs.LEVEL1Code.GDScreenFadeObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDScreenFadeObjects1[i].getBehavior("Tween").addObjectOpacityTween2("FadeIn", 0, "linear", 1, true);
}
}
{ //Subevents
gdjs.LEVEL1Code.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects1Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects1, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects1, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects1, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects1, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects1, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects1, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects1, "samlong": gdjs.LEVEL1Code.GDsamlongObjects1});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects1Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects1, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects1, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects1, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects1, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects1, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects1, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects1, "samlong": gdjs.LEVEL1Code.GDsamlongObjects1});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects4Objects = Hashtable.newFrom({"Selection": gdjs.LEVEL1Code.GDSelectionObjects4});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects4Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects4, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects4, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects4, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects4, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects4, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects4, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects4, "samlong": gdjs.LEVEL1Code.GDsamlongObjects4});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects3Objects = Hashtable.newFrom({"Selection": gdjs.LEVEL1Code.GDSelectionObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects3, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects3, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects3, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects3, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects3, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects3, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects3, "samlong": gdjs.LEVEL1Code.GDsamlongObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects3, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects3, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects3, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects3, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects3, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects3, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects3, "samlong": gdjs.LEVEL1Code.GDsamlongObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects3Objects = Hashtable.newFrom({"Selection": gdjs.LEVEL1Code.GDSelectionObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects3, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects3, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects3, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects3, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects3, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects3, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects3, "samlong": gdjs.LEVEL1Code.GDsamlongObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects3, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects3, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects3, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects3, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects3, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects3, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects3, "samlong": gdjs.LEVEL1Code.GDsamlongObjects3});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDStarParticleObjects3Objects = Hashtable.newFrom({"StarParticle": gdjs.LEVEL1Code.GDStarParticleObjects3});
gdjs.LEVEL1Code.eventsList3 = function(runtimeScene, asyncObjectsList) {

{



}


{

/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSelectionObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__Contains.func(runtimeScene, gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects3Objects, "ObjectStack", gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSelectionObjects3 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects3 */
gdjs.copyArray(runtimeScene.getObjects("StarParticle"), gdjs.LEVEL1Code.GDStarParticleObjects3);
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects3 */
{for(var i = 0, len = gdjs.LEVEL1Code.GDSelectionObjects3.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSelectionObjects3[i].getBehavior("ObjectStack").Clear((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtsExt__Card__ExplodeCard.func(runtimeScene, gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects, "Tween", gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDStarParticleObjects3Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.LEVEL1Code.eventsList4 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(gdjs.LEVEL1Code.GDAnemoneCardObjects2, gdjs.LEVEL1Code.GDAnemoneCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDBlowfishCardObjects2, gdjs.LEVEL1Code.GDBlowfishCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDCoralCardObjects2, gdjs.LEVEL1Code.GDCoralCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDCrabCardObjects2, gdjs.LEVEL1Code.GDCrabCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDPlasticBagCardObjects2, gdjs.LEVEL1Code.GDPlasticBagCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDSeagrassCardObjects2, gdjs.LEVEL1Code.GDSeagrassCardObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Selection"), gdjs.LEVEL1Code.GDSelectionObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDSnailCardObjects2, gdjs.LEVEL1Code.GDSnailCardObjects4);

gdjs.copyArray(gdjs.LEVEL1Code.GDsamlongObjects2, gdjs.LEVEL1Code.GDsamlongObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__ContainsAt.func(runtimeScene, gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects4Objects, "ObjectStack", gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects4ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects4Objects, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects4 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects4 */
{gdjs.LEVEL1Code.localVariables[0].getFromIndex(0).setString((( gdjs.LEVEL1Code.GDsamlongObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDPlasticBagCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDAnemoneCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDCoralCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDSeagrassCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDSnailCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDCrabCardObjects4.length === 0 ) ? (( gdjs.LEVEL1Code.GDBlowfishCardObjects4.length === 0 ) ? "" :gdjs.LEVEL1Code.GDBlowfishCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDCrabCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDSnailCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDSeagrassCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDCoralCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDAnemoneCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDPlasticBagCardObjects4[0].getName()) :gdjs.LEVEL1Code.GDsamlongObjects4[0].getName()));
}}

}


{

gdjs.copyArray(gdjs.LEVEL1Code.GDAnemoneCardObjects2, gdjs.LEVEL1Code.GDAnemoneCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDBlowfishCardObjects2, gdjs.LEVEL1Code.GDBlowfishCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDCoralCardObjects2, gdjs.LEVEL1Code.GDCoralCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDCrabCardObjects2, gdjs.LEVEL1Code.GDCrabCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDPlasticBagCardObjects2, gdjs.LEVEL1Code.GDPlasticBagCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDSeagrassCardObjects2, gdjs.LEVEL1Code.GDSeagrassCardObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("Selection"), gdjs.LEVEL1Code.GDSelectionObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDSnailCardObjects2, gdjs.LEVEL1Code.GDSnailCardObjects3);

gdjs.copyArray(gdjs.LEVEL1Code.GDsamlongObjects2, gdjs.LEVEL1Code.GDsamlongObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__ContainsAt.func(runtimeScene, gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects3Objects, "ObjectStack", gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects3ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects3Objects, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(gdjs.LEVEL1Code.localVariables[0].getFromIndex(0)) == (( gdjs.LEVEL1Code.GDsamlongObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDPlasticBagCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDAnemoneCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDCoralCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDSeagrassCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDSnailCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDCrabCardObjects3.length === 0 ) ? (( gdjs.LEVEL1Code.GDBlowfishCardObjects3.length === 0 ) ? "" :gdjs.LEVEL1Code.GDBlowfishCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDCrabCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDSnailCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDSeagrassCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDCoralCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDAnemoneCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDPlasticBagCardObjects3[0].getName()) :gdjs.LEVEL1Code.GDsamlongObjects3[0].getName());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pairs"), gdjs.LEVEL1Code.GDPairsObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.LEVEL1Code.GDPairsObjects3.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPairsObjects3[i].getBehavior("Text").setText("Pairs: " + runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
{ //Subevents
gdjs.LEVEL1Code.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects2Objects = Hashtable.newFrom({"Selection": gdjs.LEVEL1Code.GDSelectionObjects2});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects2Objects = Hashtable.newFrom({"BlowfishCard": gdjs.LEVEL1Code.GDBlowfishCardObjects2, "CrabCard": gdjs.LEVEL1Code.GDCrabCardObjects2, "SnailCard": gdjs.LEVEL1Code.GDSnailCardObjects2, "SeagrassCard": gdjs.LEVEL1Code.GDSeagrassCardObjects2, "CoralCard": gdjs.LEVEL1Code.GDCoralCardObjects2, "AnemoneCard": gdjs.LEVEL1Code.GDAnemoneCardObjects2, "PlasticBagCard": gdjs.LEVEL1Code.GDPlasticBagCardObjects2, "samlong": gdjs.LEVEL1Code.GDsamlongObjects2});
gdjs.LEVEL1Code.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("CardName", variable);
}
gdjs.LEVEL1Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.LEVEL1Code.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LEVEL1Code.localVariables.pop();

}


{



}


{

/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects2 */
gdjs.copyArray(asyncObjectsList.getObjects("Selection"), gdjs.LEVEL1Code.GDSelectionObjects2);

/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__ObjectStack__Contains.func(runtimeScene, gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDSelectionObjects2Objects, "ObjectStack", gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects2ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDSelectionObjects2 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects2 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects2 */
{for(var i = 0, len = gdjs.LEVEL1Code.GDSelectionObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSelectionObjects2[i].getBehavior("ObjectStack").Clear((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects2[i].getBehavior("ThreeDFlip").FlipToSecond(true, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.LEVEL1Code.asyncCallback20526244 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.LEVEL1Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("AnemoneCard"), gdjs.LEVEL1Code.GDAnemoneCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("BlowfishCard"), gdjs.LEVEL1Code.GDBlowfishCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("CoralCard"), gdjs.LEVEL1Code.GDCoralCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("CrabCard"), gdjs.LEVEL1Code.GDCrabCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("PlasticBagCard"), gdjs.LEVEL1Code.GDPlasticBagCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("SeagrassCard"), gdjs.LEVEL1Code.GDSeagrassCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("SnailCard"), gdjs.LEVEL1Code.GDSnailCardObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("samlong"), gdjs.LEVEL1Code.GDsamlongObjects2);

{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects2[i].activateBehavior("ButtonFSM", true);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects2[i].activateBehavior("ButtonFSM", true);
}
}
{ //Subevents
gdjs.LEVEL1Code.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.LEVEL1Code.localVariables.length = 0;
}
gdjs.LEVEL1Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.LEVEL1Code.localVariables);
for (const obj of gdjs.LEVEL1Code.GDAnemoneCardObjects1) asyncObjectsList.addObject("AnemoneCard", obj);
for (const obj of gdjs.LEVEL1Code.GDBlowfishCardObjects1) asyncObjectsList.addObject("BlowfishCard", obj);
for (const obj of gdjs.LEVEL1Code.GDCoralCardObjects1) asyncObjectsList.addObject("CoralCard", obj);
for (const obj of gdjs.LEVEL1Code.GDCrabCardObjects1) asyncObjectsList.addObject("CrabCard", obj);
for (const obj of gdjs.LEVEL1Code.GDPlasticBagCardObjects1) asyncObjectsList.addObject("PlasticBagCard", obj);
for (const obj of gdjs.LEVEL1Code.GDSeagrassCardObjects1) asyncObjectsList.addObject("SeagrassCard", obj);
for (const obj of gdjs.LEVEL1Code.GDSelectionObjects1) asyncObjectsList.addObject("Selection", obj);
for (const obj of gdjs.LEVEL1Code.GDSnailCardObjects1) asyncObjectsList.addObject("SnailCard", obj);
for (const obj of gdjs.LEVEL1Code.GDsamlongObjects1) asyncObjectsList.addObject("samlong", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.LEVEL1Code.asyncCallback20526244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LEVEL1Code.eventsList7 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSelectionObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSelectionObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSelectionObjects1[i].getBehavior("ObjectStack").Height((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSelectionObjects1[k] = gdjs.LEVEL1Code.GDSelectionObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSelectionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects1Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects1 */
{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i].activateBehavior("ButtonFSM", false);
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects1[i].activateBehavior("ButtonFSM", false);
}
}
{ //Subevents
gdjs.LEVEL1Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL1Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("AnemoneCard"), gdjs.LEVEL1Code.GDAnemoneCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlowfishCard"), gdjs.LEVEL1Code.GDBlowfishCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("CoralCard"), gdjs.LEVEL1Code.GDCoralCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("CrabCard"), gdjs.LEVEL1Code.GDCrabCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlasticBagCard"), gdjs.LEVEL1Code.GDPlasticBagCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SeagrassCard"), gdjs.LEVEL1Code.GDSeagrassCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("SnailCard"), gdjs.LEVEL1Code.GDSnailCardObjects1);
gdjs.copyArray(runtimeScene.getObjects("samlong"), gdjs.LEVEL1Code.GDsamlongObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDBlowfishCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDBlowfishCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDBlowfishCardObjects1[k] = gdjs.LEVEL1Code.GDBlowfishCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDBlowfishCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCrabCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCrabCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCrabCardObjects1[k] = gdjs.LEVEL1Code.GDCrabCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCrabCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSnailCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSnailCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSnailCardObjects1[k] = gdjs.LEVEL1Code.GDSnailCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSnailCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSeagrassCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSeagrassCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSeagrassCardObjects1[k] = gdjs.LEVEL1Code.GDSeagrassCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSeagrassCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCoralCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCoralCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCoralCardObjects1[k] = gdjs.LEVEL1Code.GDCoralCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCoralCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDAnemoneCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDAnemoneCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDAnemoneCardObjects1[k] = gdjs.LEVEL1Code.GDAnemoneCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDAnemoneCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDPlasticBagCardObjects1[k] = gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDsamlongObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDsamlongObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDsamlongObjects1[k] = gdjs.LEVEL1Code.GDsamlongObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDsamlongObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDBlowfishCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDBlowfishCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDBlowfishCardObjects1[k] = gdjs.LEVEL1Code.GDBlowfishCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDBlowfishCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCrabCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCrabCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCrabCardObjects1[k] = gdjs.LEVEL1Code.GDCrabCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCrabCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSnailCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSnailCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSnailCardObjects1[k] = gdjs.LEVEL1Code.GDSnailCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSnailCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDSeagrassCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDSeagrassCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDSeagrassCardObjects1[k] = gdjs.LEVEL1Code.GDSeagrassCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDSeagrassCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDCoralCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDCoralCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDCoralCardObjects1[k] = gdjs.LEVEL1Code.GDCoralCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDCoralCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDAnemoneCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDAnemoneCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDAnemoneCardObjects1[k] = gdjs.LEVEL1Code.GDAnemoneCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDAnemoneCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDPlasticBagCardObjects1[k] = gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDsamlongObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDsamlongObjects1[i].getBehavior("ThreeDFlip").IsFlipped((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDsamlongObjects1[k] = gdjs.LEVEL1Code.GDsamlongObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDsamlongObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDAnemoneCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDBlowfishCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCoralCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDCrabCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDPlasticBagCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDSeagrassCardObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Selection"), gdjs.LEVEL1Code.GDSelectionObjects1);
/* Reuse gdjs.LEVEL1Code.GDSnailCardObjects1 */
/* Reuse gdjs.LEVEL1Code.GDsamlongObjects1 */
{for(var i = 0, len = gdjs.LEVEL1Code.GDSelectionObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSelectionObjects1[i].getBehavior("ObjectStack").AddOnTop(gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDBlowfishCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCrabCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSnailCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDSeagrassCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDCoralCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDAnemoneCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDPlasticBagCardObjects1ObjectsGDgdjs_9546LEVEL1Code_9546GDsamlongObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDBlowfishCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlowfishCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCrabCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCrabCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSnailCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSnailCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDSeagrassCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDSeagrassCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDCoralCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCoralCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDAnemoneCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDAnemoneCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDPlasticBagCardObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.LEVEL1Code.GDsamlongObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDsamlongObjects1[i].getBehavior("ThreeDFlip").FlipToSecond(false, 0.25, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cockatrice_playcard.mp3", false, 100, 1);
}
{ //Subevents
gdjs.LEVEL1Code.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL1Code.mapOfEmptyGDBlowfishCardObjectsEmptyGDCrabCardObjectsEmptyGDSnailCardObjectsEmptyGDSeagrassCardObjectsEmptyGDCoralCardObjectsEmptyGDAnemoneCardObjectsEmptyGDPlasticBagCardObjectsEmptyGDsamlongObjects = Hashtable.newFrom({"BlowfishCard": [], "CrabCard": [], "SnailCard": [], "SeagrassCard": [], "CoralCard": [], "AnemoneCard": [], "PlasticBagCard": [], "samlong": []});
gdjs.LEVEL1Code.asyncCallback20534724 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.LEVEL1Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "LEVEL1", false);
}gdjs.LEVEL1Code.localVariables.length = 0;
}
gdjs.LEVEL1Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.LEVEL1Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.LEVEL1Code.asyncCallback20534724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LEVEL1Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LEVEL1Code.mapOfEmptyGDBlowfishCardObjectsEmptyGDCrabCardObjectsEmptyGDSnailCardObjectsEmptyGDSeagrassCardObjectsEmptyGDCoralCardObjectsEmptyGDAnemoneCardObjectsEmptyGDPlasticBagCardObjectsEmptyGDsamlongObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20532708);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackBackground"), gdjs.LEVEL1Code.GDBlackBackgroundObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/Rise.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.LEVEL1Code.GDBlackBackgroundObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlackBackgroundObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDBlackBackgroundObjects2.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDBlackBackgroundObjects2[i].getBehavior("Tween").addObjectOpacityTween2("FadeOut", 175, "linear", 1, false);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewgameButton"), gdjs.LEVEL1Code.GDNewgameButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "UI");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL1Code.GDNewgameButtonObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL1Code.GDNewgameButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL1Code.GDNewgameButtonObjects1[k] = gdjs.LEVEL1Code.GDNewgameButtonObjects1[i];
        ++k;
    }
}
gdjs.LEVEL1Code.GDNewgameButtonObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/pop.ogg", false, 100, 1);
}
{ //Subevents
gdjs.LEVEL1Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDCloseButtonObjects1Objects = Hashtable.newFrom({"CloseButton": gdjs.LEVEL1Code.GDCloseButtonObjects1});
gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDRedButtonWithGoldFrameObjects1Objects = Hashtable.newFrom({"RedButtonWithGoldFrame": gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1});
gdjs.LEVEL1Code.eventsList11 = function(runtimeScene) {

{


gdjs.LEVEL1Code.eventsList2(runtimeScene);
}


{


gdjs.LEVEL1Code.eventsList8(runtimeScene);
}


{


gdjs.LEVEL1Code.eventsList10(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.LEVEL1Code.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.LEVEL1Code.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDNewTiledSpriteObjects1[i].setXOffset(gdjs.LEVEL1Code.GDNewTiledSpriteObjects1[i].getXOffset() + (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CloseButton"), gdjs.LEVEL1Code.GDCloseButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDCloseButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL1Code.GDCloseButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("GroundTile"), gdjs.LEVEL1Code.GDGroundTileObjects1);
gdjs.copyArray(runtimeScene.getObjects("petunjuk"), gdjs.LEVEL1Code.GDpetunjukObjects1);
{for(var i = 0, len = gdjs.LEVEL1Code.GDGroundTileObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDGroundTileObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDCloseButtonObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDCloseButtonObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDpetunjukObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDpetunjukObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timer");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("waktu"), gdjs.LEVEL1Code.GDwaktuObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(120 - gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timer"));
}{for(var i = 0, len = gdjs.LEVEL1Code.GDwaktuObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDwaktuObjects1[i].getBehavior("Text").setText("waktu : " + gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RedButtonWithGoldFrame"), gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1);
gdjs.copyArray(runtimeScene.getObjects("game_over"), gdjs.LEVEL1Code.GDgame_9595overObjects1);
gdjs.copyArray(runtimeScene.getObjects("tulisan_game_over"), gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1);
{for(var i = 0, len = gdjs.LEVEL1Code.GDgame_9595overObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDgame_9595overObjects1[i].getBehavior("Tween").addObjectPositionYTween2("gameover", 0, "easeOutQuad", 1, false);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1[i].getBehavior("Tween").addObjectPositionYTween2("gameover", 100, "easeOutQuad", 1, false);
}
}{for(var i = 0, len = gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1.length ;i < len;++i) {
    gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1[i].getBehavior("Tween").addObjectPositionYTween2("gameover", 300, "easeOutQuad", 1, false);
}
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "timer");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedButtonWithGoldFrame"), gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LEVEL1Code.mapOfGDgdjs_9546LEVEL1Code_9546GDRedButtonWithGoldFrameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "LEVEL1", false);
}}

}


};

gdjs.LEVEL1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LEVEL1Code.GDCrabCardObjects1.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects2.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects3.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects4.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects5.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects1.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects2.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects3.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects4.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects5.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects1.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects2.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects3.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects4.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects5.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects1.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects2.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects3.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects4.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects5.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects1.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects2.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects3.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects4.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects5.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects3.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects4.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects5.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects1.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects2.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects3.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects4.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects5.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects1.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects3.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects4.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects5.length = 0;
gdjs.LEVEL1Code.GDBoardObjects1.length = 0;
gdjs.LEVEL1Code.GDBoardObjects2.length = 0;
gdjs.LEVEL1Code.GDBoardObjects3.length = 0;
gdjs.LEVEL1Code.GDBoardObjects4.length = 0;
gdjs.LEVEL1Code.GDBoardObjects5.length = 0;
gdjs.LEVEL1Code.GDPairsObjects1.length = 0;
gdjs.LEVEL1Code.GDPairsObjects2.length = 0;
gdjs.LEVEL1Code.GDPairsObjects3.length = 0;
gdjs.LEVEL1Code.GDPairsObjects4.length = 0;
gdjs.LEVEL1Code.GDPairsObjects5.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects1.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects2.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects3.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects4.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects5.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects1.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects2.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects3.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects4.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects5.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects1.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects2.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects3.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects4.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects5.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects1.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects2.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects3.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects4.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects5.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects1.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects2.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects3.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects4.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects5.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects1.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects2.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects3.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects4.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects5.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects1.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects2.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects3.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects4.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects5.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects1.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects2.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects3.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects4.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects5.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects1.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects2.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects3.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects4.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects5.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects1.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects2.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects3.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects4.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects5.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects1.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects2.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects3.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects4.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects5.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects1.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects2.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects3.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects4.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects5.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects1.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects2.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects3.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects4.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects5.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects2.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects3.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects4.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects5.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects2.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects3.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects4.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects5.length = 0;

gdjs.LEVEL1Code.eventsList11(runtimeScene);
gdjs.LEVEL1Code.GDCrabCardObjects1.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects2.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects3.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects4.length = 0;
gdjs.LEVEL1Code.GDCrabCardObjects5.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects1.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects2.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects3.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects4.length = 0;
gdjs.LEVEL1Code.GDSnailCardObjects5.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects1.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects2.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects3.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects4.length = 0;
gdjs.LEVEL1Code.GDSeagrassCardObjects5.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects1.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects2.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects3.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects4.length = 0;
gdjs.LEVEL1Code.GDCoralCardObjects5.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects1.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects2.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects3.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects4.length = 0;
gdjs.LEVEL1Code.GDAnemoneCardObjects5.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects1.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects2.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects3.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects4.length = 0;
gdjs.LEVEL1Code.GDPlasticBagCardObjects5.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects1.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects2.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects3.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects4.length = 0;
gdjs.LEVEL1Code.GDBlowfishCardObjects5.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects1.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects2.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects3.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects4.length = 0;
gdjs.LEVEL1Code.GDPositionPlaceholderObjects5.length = 0;
gdjs.LEVEL1Code.GDBoardObjects1.length = 0;
gdjs.LEVEL1Code.GDBoardObjects2.length = 0;
gdjs.LEVEL1Code.GDBoardObjects3.length = 0;
gdjs.LEVEL1Code.GDBoardObjects4.length = 0;
gdjs.LEVEL1Code.GDBoardObjects5.length = 0;
gdjs.LEVEL1Code.GDPairsObjects1.length = 0;
gdjs.LEVEL1Code.GDPairsObjects2.length = 0;
gdjs.LEVEL1Code.GDPairsObjects3.length = 0;
gdjs.LEVEL1Code.GDPairsObjects4.length = 0;
gdjs.LEVEL1Code.GDPairsObjects5.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects1.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects2.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects3.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects4.length = 0;
gdjs.LEVEL1Code.GDNewGameObjects5.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects1.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects2.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects3.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects4.length = 0;
gdjs.LEVEL1Code.GDYouWonObjects5.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects1.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects2.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects3.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects4.length = 0;
gdjs.LEVEL1Code.GDStarParticleObjects5.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects1.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects2.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects3.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects4.length = 0;
gdjs.LEVEL1Code.GDScreenFadeObjects5.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects1.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects2.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects3.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects4.length = 0;
gdjs.LEVEL1Code.GDBlackBackgroundObjects5.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects1.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects2.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects3.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects4.length = 0;
gdjs.LEVEL1Code.GDSelectionObjects5.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects1.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects2.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects3.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects4.length = 0;
gdjs.LEVEL1Code.GDNewgameButtonObjects5.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.LEVEL1Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects1.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects2.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects3.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects4.length = 0;
gdjs.LEVEL1Code.GDsamlongObjects5.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects1.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects2.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects3.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects4.length = 0;
gdjs.LEVEL1Code.GDGroundTileObjects5.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects1.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects2.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects3.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects4.length = 0;
gdjs.LEVEL1Code.GDCloseButtonObjects5.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects1.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects2.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects3.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects4.length = 0;
gdjs.LEVEL1Code.GDpetunjukObjects5.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects1.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects2.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects3.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects4.length = 0;
gdjs.LEVEL1Code.GDwaktuObjects5.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects1.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects2.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects3.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects4.length = 0;
gdjs.LEVEL1Code.GDgame_9595overObjects5.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects1.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects2.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects3.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects4.length = 0;
gdjs.LEVEL1Code.GDtulisan_9595game_9595overObjects5.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects1.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects2.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects3.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects4.length = 0;
gdjs.LEVEL1Code.GDRedButtonWithGoldFrameObjects5.length = 0;


return;

}

gdjs['LEVEL1Code'] = gdjs.LEVEL1Code;
