gdjs.dialogCode = {};
gdjs.dialogCode.localVariables = [];
gdjs.dialogCode.GDsupriObjects1= [];
gdjs.dialogCode.GDsupriObjects2= [];
gdjs.dialogCode.GDsupriObjects3= [];
gdjs.dialogCode.GDtejoObjects1= [];
gdjs.dialogCode.GDtejoObjects2= [];
gdjs.dialogCode.GDtejoObjects3= [];
gdjs.dialogCode.GDdialogObjects1= [];
gdjs.dialogCode.GDdialogObjects2= [];
gdjs.dialogCode.GDdialogObjects3= [];


gdjs.dialogCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "waktu") >= 0.05;
if (isConditionTrue_0) {
{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "waktu");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


};gdjs.dialogCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "New dialogue tree");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "waktu");
}{gdjs.dialogueTree.startFrom("Start");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dialog"), gdjs.dialogCode.GDdialogObjects1);
{for(var i = 0, len = gdjs.dialogCode.GDdialogObjects1.length ;i < len;++i) {
    gdjs.dialogCode.GDdialogObjects1[i].setBBText(gdjs.dialogueTree.getClippedLineText());
}
}
{ //Subevents
gdjs.dialogCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.dialogCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.dialogCode.GDsupriObjects1.length = 0;
gdjs.dialogCode.GDsupriObjects2.length = 0;
gdjs.dialogCode.GDsupriObjects3.length = 0;
gdjs.dialogCode.GDtejoObjects1.length = 0;
gdjs.dialogCode.GDtejoObjects2.length = 0;
gdjs.dialogCode.GDtejoObjects3.length = 0;
gdjs.dialogCode.GDdialogObjects1.length = 0;
gdjs.dialogCode.GDdialogObjects2.length = 0;
gdjs.dialogCode.GDdialogObjects3.length = 0;

gdjs.dialogCode.eventsList1(runtimeScene);
gdjs.dialogCode.GDsupriObjects1.length = 0;
gdjs.dialogCode.GDsupriObjects2.length = 0;
gdjs.dialogCode.GDsupriObjects3.length = 0;
gdjs.dialogCode.GDtejoObjects1.length = 0;
gdjs.dialogCode.GDtejoObjects2.length = 0;
gdjs.dialogCode.GDtejoObjects3.length = 0;
gdjs.dialogCode.GDdialogObjects1.length = 0;
gdjs.dialogCode.GDdialogObjects2.length = 0;
gdjs.dialogCode.GDdialogObjects3.length = 0;


return;

}

gdjs['dialogCode'] = gdjs.dialogCode;
